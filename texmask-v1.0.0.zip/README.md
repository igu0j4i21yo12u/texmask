# TexMask

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**ブラウザ上でテキストを安全にマスキングできる、完全クライアントサイドのWebツールです。**

外部サーバーへのデータ送信は一切行わず、すべての処理がブラウザ内で完結します。機密情報を含むログやメール、設定ファイルなどを安心してマスキングできます。

🔗 **[デモサイト (GitHub Pages)](https://igs-service.github.io/texmask/)**

---

## 主な機能

- **📝 自動マスキング**: テキストを貼り付けると即座にマスキング
- **🔐 完全ローカル処理**: データは外部に送信されません
- **🎯 豊富なルール**: IP/Email/電話番号/住所/API Key など、たくさんのパターンに対応
- **📚 辞書機能**: 会社名や個人名など、独自の単語を登録可能
- **🏠 住所辞書**: 日本全国の都道府県・市区町村を自動マスキング（[Geolonia 住所データ](https://github.com/geolonia/japanese-addresses)を活用）
- **💾 設定の保存/共有**: JSON形式でエクスポート/インポート可能
- **🌐 オフライン動作**: 一度読み込めばインターネット接続不要で動作（住所辞書の更新時のみ必要）

---

## 使い方

### 基本的な使い方

1. **[デモサイト](https://igs-service.github.io/texmask/)** にアクセス
2. 左側の「入力」欄にテキストを貼り付け
3. 右側の「出力」欄に自動でマスキング結果が表示されます

### マスキングモード

- **仮名化（Pseudonymize）**: `<IPv4_001>`, `<EMAIL_002>` のように識別子を保持
- **伏せ字（Redact）**: `*****`, `<MASKED>`, `<EMAIL_REDACTED>` のように完全に隠蔽

### カスタマイズ

- **基本設定タブ**: ルールの有効/無効、検出順序の変更
- **任意辞書タブ**: 会社名・個人名・サーバー名など独自の単語を登録
- **住所辞書タブ**: 日本の住所データを一括マスキング

### 設定の保存・共有

- 右下の「マイ設定」ボタンから設定を保存
- 「JSONに保存」でファイルとしてエクスポート
- チーム内で設定を共有したい場合に便利です

---

## ローカルで動かす

```bash
# リポジトリをクローン
git clone https://github.com/igs-service/texmask.git
cd texmask

# ブラウザで開く
open index.html
# または
python -m http.server 8000
# http://localhost:8000/ にアクセス
```

---

## 対応パターン（一部）

| 種類 | 例 |
| ---- | --- |
| IPv4 | `192.168.0.10` |
| IPv6 | `2001:db8::1` |
| Email | `user@example.com` |
| 電話番号（日本） | `03-1234-5678`, `090-1234-5678` |
| 電話番号（国際） | `+81 3 1234 5678` |
| 郵便番号 | `100-0001` |
| FQDN | `app.example.com` |
| API Key | `XyZ123abcDEF456...` |
| JWT | `eyJhbGciOiJIUzI1NiIs...` |
| AWS Account ID | `123456789012` |
| Azure Subscription ID | `1a2b3c4d-5e6f-7a8b-...` |
| GCP Project ID | `my-project-123` |
| 住所 | `東京都千代田区丸の内` |

その他、たくさんのパターンに対応しています。

---

## プライバシーとセキュリティ

- ✅ **データは外部に送信されません**: すべての処理がブラウザ内で完結
- ✅ **オープンソース**: コードは公開されており、動作を検証可能
- ✅ **設定の保存**: ブラウザの localStorage に保存（ルールや辞書の設定を記憶します）
- ⚠️ **住所辞書の更新**: 「最新版に更新」ボタン使用時のみ、GitHub から辞書データを取得します

**注**: アプリ内のサンプルデータ（会社名・個人名など）はすべて架空のものです。

---

## 開発・テスト

### テストの実行

```bash
# ローカルサーバーを起動
python -m http.server 8000

# テストページを開く
open http://localhost:8000/tests/test.html
```

### ファイル構成

```
.
├── index.html          # メインHTML
├── app.js              # マスキングロジック
├── styles.css          # スタイル定義
├── address-dict.js     # 住所辞書データ
├── README.md           # このファイル
├── LICENSE             # MITライセンス
├── tests/              # テスト関連
│   ├── test.html       # テストページ
│   ├── test-*.js       # 個別テストスクリプト
│   └── TEST_REPORT.md  # テストレポート
└── scripts/            # ビルド/開発スクリプト
    └── build-address-dict.js  # 住所辞書ビルドスクリプト
```

---

## ライセンス

MIT License - 詳細は [LICENSE](LICENSE) をご覧ください。

---

## クレジット

- 住所辞書データ: [Geolonia 住所データ](https://github.com/geolonia/japanese-addresses) (CC BY 4.0)
- アイコン: なし（テキストベースUI）

---

## 貢献

バグ報告や機能要望は [Issues](https://github.com/igs-service/texmask/issues) へお願いします。
プルリクエストも歓迎です。

---

## よくある質問

### Q. は？これ何がうれしいの？

A. ちゃっぴー（ChatGPT）とかに投げるテキストをサクッとマスクできるのでうれしいに決まってるでしょ。

### Q. データは本当に外部に送信されませんか？
A. はい。すべての処理がブラウザ内で完結します。ネットワークタブで確認できます（住所辞書の更新時のみ GitHub へアクセスします）。

### Q. オフラインでも使えますか？
A. はい。以下の方法で完全オフライン利用が可能です。

- **リポジトリをクローン**: `git clone https://github.com/igs-service/texmask.git` してローカルで `index.html` を開く
- **ZIPダウンロード**: [Releases](https://github.com/igs-service/texmask/releases) から最新版をダウンロードして展開

GitHub Pages経由の場合、一度読み込めばブラウザキャッシュが有効な間は動作しますが、再アクセス時は接続が必要です。

### Q. スマホでも使えますか？
A. はい。レスポンシブ対応しており、モバイルブラウザでも動作します。

### Q. 設定をチームで共有できますか？
A. はい。「JSONに保存」で設定ファイルをエクスポートし、Git管理やチャットで共有できます。

### Q. プロジェクト名の由来は？
A. タコス好きなのでTex-Mexをもじって "Texmask" にしました🌮

---

## まとめ

Enjoy safe text masking! 🎭
